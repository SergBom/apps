<?php   

include_once("{$_SERVER['DOCUMENT_ROOT']}/php/init.php");
header('Content-type: text/html; charset=utf-8');
/*-------------------------- Входные переменные -----------------------------*/
/*---------------------------------------------------------------------------*/
    $link = ConnectMyDB('portal');
/*---------------------------------------------------------------------------*/


//$data_in	  = isset($_POST['data'])		? $_POST['data']	:  "";
$data=[];
if(!isset($_POST['data'])){
	$strSQL = "SELECT id, concat(userFm,' ',userIm,' ',userOt)as name FROM `portal`.`prt#users`";
	$res_user = $link->query($strSQL);
	//$strSQL = "SELECT id, app_nik as name FROM `portal`.`prt#groups` ORDER  by id";
	//$res_group = $link->query($strSQL);
	//$all_group=array();
	//$i=1;
	
	while( $row_user = $res_user->fetch_array() ){
		$sql = "SELECT ug.group_id, g.app_nik, g.name FROM `portal`.`prt#user_group` ug
				left join `portal`.`prt#groups` g on ug.group_id=g.id
				where ug.user_id={$row_user['id']}";
		array_push($data, $row_user);				
		while( $row_group = $res_user->fetch_array() ){
			array_push($data, $user);
		}
	}
	
	
	
	
	while($rows = mysqli_fetch_array($res_group)){
		$all_group[$i]['id']=$rows['id'];
		$all_group[$i]['name']=$rows['name'];
		//echo "id=" ,$all_group[$i]['id']," name=",$all_group[$i]['name'],"<br>";
		$i++;
	}
	$count= count ($all_group);
//$strSQL = "SELECT user_id, group_id FROM `portal`.`prt#user_group`";
//$res_prava = $link->query($strSQL);
while($user = mysqli_fetch_array($res_user)) {
   // echo "id=" ,$user['id']," name=",$user['name'],"<br>";
  for ($i = 1; $i<=$count; $i++) {
	// echo "groupid=" ,$group['id']," name=",$group['name'],"<br>";
	 $var1=$user['id'];
	 $var2=$all_group[$i]['id'];
	$strSQL = "SELECT group_id FROM `portal`.`prt#user_group` where user_id=$var1 and group_id=$var2";
	$res_prava = $link->query($strSQL);
	list($pravo) = mysqli_fetch_array($res_prava);
	$pravo	  = isset($pravo)		? 1	:  0;
		//$row=array($group['name']=>$pravo);
		//	echo "тип row=".gettype($row)."тип user=".gettype($user);
	$user[$all_group[$i]['name']]=$pravo;
	
	  
  }
  
  
   array_push($data, $user);
}
$c = array('success'=>0,'data'=>$data);
		echo json_encode($c);
 
 
 }
 else{
//print_r( $_POST);
//$params = $_POST['data'];
//print_r($_POST['data'];
//echo gettype($params).'  ';
$v1=json_decode($_POST['data'],true);
//echo gettype($v1);
//print_r($v1 );

$v2=array_keys($v1);
//print_r($v2 );

$id=$v1['id'];
$group=$v2[0];
$val=$v1[$v2[0]];
//$strSQL = "SELECT id, name, true as group1,true as group2 FROM test";
//$result = $link->query($strSQL);
//switch ($group){
//	case "admin":
//    echo "admin<br>";
//    break;
//	case "users":
//    echo "users<br>";
//    break;
//	case "guest":
//    echo "guest<br>";
//    break;
//	default:
//	break;

//}
if($val=='1'){//создаем новый
$strSQL = "CALL `proc#user_group_add`('$id', '$group')";
//echo $strSQL;

$result = $link->query($strSQL);
	
	$c = array('success'=>0);
		echo json_encode($c);
}
else{//удаляем существующий

	$strSQL = "CALL `proc#user_group_delete`('$id', '$group')";
//echo $strSQL;

$result = $link->query($strSQL);
	
	$c = array('success'=>0);
		echo json_encode($c);
	
	
}




 }

	?>


