

 <?php   

include_once("{$_SERVER['DOCUMENT_ROOT']}/php/init.php");
header('Content-type: text/html; charset=utf-8');
/*-------------------------- Входные переменные -----------------------------*/
/*---------------------------------------------------------------------------*/
    $link = ConnectMyDB('portal');
/*---------------------------------------------------------------------------*/

	$strSQL = "SELECT id, username as name FROM `portal`.`prt#users` ";
$result = $link->query($strSQL);

$data = array();


while($row = mysqli_fetch_array($result)) {
    
   //echo "id=" ,$row['id']," name=",$row['name']," data=",$row['data'],"<br>";
  
   array_push($data, $row);
}
$c = array('success'=>0,'data'=>$data);
		echo json_encode($c);
 

	?>


